
# Calibration:
CalibrationPlot_CR <- function(predProbs, lambdas, whichCR, outcome,
                               add = FALSE, color = 1,
                               ylim = c(0, 1), xlim = c(0, 1), ...){

  #' Cause-specific calibration plots following van Hoorde
  #'
  #'
  #' This function computes the IPCW which will then be used to compute scores
  #' @param predProbs have to be on the response scale. It is a matrix with as many
  #' columns as their are possible outcomes and as many rows as there are
  #' observations / admission-days. The colnames need to be the the names of
  #' the potential outcomes.
  #' @param lambdas the linear predictors / the log(mu[,i]/mu[,1])
  #' @param whichCR name of the outcome of interest considered for the CP
  #' @param outcome vector with the events
  #' @param add should the points be added to an existing plot?
  #' @param color the color of the points in the plot
  #' @param ylim the limits of the y-axes in the plot
  #' @param xlim the limits of the x-axes in the plot
  #' @param ... futher plot parameters
  #' @return the calibration plot
  #' @export

  fitp <- vglm(outcome ~ lambdas, family = multinomial(refLevel = 1))

  c <- which(colnames(predProbs) == whichCR)

  probs <- split(predProbs, col(predProbs))

  p <- unlist(probs[[c]])
  matplot(p, fitted(fitp)[ , whichCR], type = "p", pch = '.', cex = 2,
          col = makeTransparent(color, 25),
          lwd = 1, xlim = xlim, ylim = ylim, add = add, ...)
  points(smooth.spline(p, fitted(fitp)[ , whichCR], spar = 1),
         type="l", col = color, lwd = 1.5)
  abline(a = 0, b = 1, lty = "dashed")
}


makeTransparent <- function(someColor, alpha=100) scales::alpha(someColor, alpha/100)

# calibration slope for competing risks (CS)
CalibrationSlope_CR <- function(lambdas, outcome, r = 1){

  #' Cause-specific calibration slopes (CS)
  #'
  #'
  #' This function computes the cause-specific CS
  #' @param lambdas the linear predictors / the log(mu[,i]/mu[,1])
  #' @param outcome vector with the events
  #' @param r the indicator of the reference category among levels(outcome)
  #' @return the cause-specific CS with their 95% CI
  #' @export
  #'
  #     * outcome: the vector with the events
  #     * r: the indicator of the reference category among levels(outcome)

  # --> see supMat from https://onlinelibrary.wiley.com/doi/abs/10.1002/sim.6114

  nbCR <- ncol(lambdas) # how many competing risks are there??
  # constraints list for the fit of the multinomial regression model
  I <- diag(nbCR)
  clist <- list(I)
  for (i in 1:nbCR){
    clist[[i+1]] <- cbind(I[ , i])
  }
  names(clist) <- c("(Intercept)",
                    sapply(1:nbCR, function(i) paste("lp", i, sep = "")))

  # the dataframe for the multinomial regression later:
  df <- data.frame(cbind(outcome, lambdas))
  names(df) <- c('outcome',
                 sapply(1:nbCR, function(i) paste("lp", i, sep = "")))

  # the formual for the multinomial regression
  CM_form <- paste0('outcome ~ ',
                    paste(sapply(1:nbCR, function(i) paste0('lp', i)),
                          collapse = ' + '))

  # collect the slopes of the multinomial regression with the linear preds as
  # only variable(s)
  slopes <- vglm(CM_form, family = multinomial(refLevel = r),
                 data = df,
                 constraints = clist)
  coeffslopes <- coefficients(slopes)[(nbCR+1):length(coefficients(slopes))]
  CM_form_null <- paste0('outcome ~ ',
                         paste0(sapply(1:nbCR,
                                       function(i) paste0('offset(lp', i,')')),
                                collapse = ' + '))
  deviancewithout <- vglm(CM_form_null, data = df,
                          family = multinomial(refLevel = r),
                          refLevel = r)
  poverall <- pchisq(deviance(deviancewithout) - deviance(slopes), df = 2*nbCR, lower.tail = FALSE)
  # for the confidence intervals:
  se <- sqrt(diag(vcov(slopes)))
  cis <- list()
  for(i in 1:nbCR){
    cis[[i]] <- cbind(LL = coeffslopes[i] - qnorm(0.975) * se[nbCR + i],
                      CS = coeffslopes[i],
                      UL = coeffslopes[i] + qnorm(0.975) * se[nbCR + i])
  }
  names(cis) <- names(table(outcome))[-1]
  return(list(cis = cis, poverall = poverall))
}


CalibrationIntercept_CR <- function(lambdas, outcome, r = 1){

  #' Cause-specific calibration intercepts
  #'
  #'
  #' This function computes the cause-specific calibration intercepts
  #' @param lambdas the linear predictors / the log(mu[,i]/mu[,1])
  #' @param outcome vector with the events
  #' @param r the indicator of the reference category among levels(outcome)
  #' @return the cause-specific calibration intercepts with their 95% CI
  #' @export

  # --> see supMat from https://onlinelibrary.wiley.com/doi/abs/10.1002/sim.6114

  int <- vglm(outcome ~ 1, offset = lambdas, family = multinomial(refLevel = r))
  CI <- coefficients(int)
  names(CI) <- names(table(outcome))[-1]
  return(CI)
}

CalibrationPlot_BERGER_SCHMID<- function(predProbs, lambdas, whichCR, outcome,
                                         add = FALSE, color = 1, pch = 20,
                                         ylim = c(0, 1), xlim = c(0, 1),
                                         regressionline = FALSE,
                                         lty = 1, ...){

  #' Cause-specific calibration plot following Berger and Schmid
  #'
  #'
  #' This function ....
  #' @param predProbs have to be on the response scale. It is a matrix with as many
  #' columns as their are possible outcomes and as many rows as there are
  #' observations / admission-days. The colnames need to be the the names of
  #' the potential outcomes.
  #' @param lambdas the linear predictors / the log(mu[,i]/mu[,1])
  #' @param whichCR name of the outcome of interest considered for the CP
  #' @param outcome vector with the events
  #' @param add should the points be added to an existing plot?
  #' @param color the color of the points in the plot
  #' @param ylim the limits of the y-axes in the plot
  #' @param xlim the limits of the x-axes in the plot
  #' @param regressionline should a regression line be added (default = FALSE)
  #' @param ... futher plot parameters
  #' @return the calibration plot
  #' @export


  c <- which(colnames(predProbs) == whichCR)
  quantiles <- quantile(predProbs[, c], probs = seq(0, 1, length.out = 20))
  sub <- cut(predProbs[, c], breaks = quantiles)
  obs <- sapply(split(outcome == whichCR, f=sub), mean)
  pred <- sapply(split(predProbs[, c],
                       f = cut(predProbs[, c], breaks = quantiles)), mean)
  if (!add){
    plot(pred, obs, type = "p", pch = pch, col = makeTransparent(color, 50),
         xlim = xlim, ylim = ylim, ...)
    if (regressionline)
      abline(lm(pred~obs), col = color)
    abline(a = 0, b = 1, lwd = 1.5, lty = "dashed")
    } else {
      points(pred, obs, type = "p", pch = pch, col = makeTransparent(color, 50))
      if (regressionline)
        abline(lm(pred~obs), col = color, lty = lty)
      }
}

CS_CI_p_CR <- function(lambdas, outcome, r = 1){

  #' Calibration
  #'
  #'
  #' This function computes the cause-specific calibration slopes,
  #' the cause-specific calibration intercepts as well as the p-values form
  #' miscalibration tests.
  #' @param lambdas the linear predictors / the log(mu[,i]/mu[,1])
  #' @param outcome vector with the events
  #' @param r the indicator of the reference category among levels(outcome)
  #' @return the cause-specific CS with their 95% CI
  #' @export
  #'

  # --> see supMat from https://onlinelibrary.wiley.com/doi/abs/10.1002/sim.6114

  nbCR <- ncol(lambdas) # how many competing risks are there??
  # constraints list for the fit of the multinomial regression model
  I <- diag(nbCR)
  clist <- list(I)
  for (i in 1:nbCR){
    clist[[i+1]] <- cbind(I[ , i])
  }
  names(clist) <- c("(Intercept)",
                    sapply(1:nbCR, function(i) paste("lp", i, sep = "")))

  # the dataframe for the multinomial regression later:
  df <- data.frame(cbind(outcome, lambdas))
  names(df) <- c('outcome',
                 sapply(1:nbCR, function(i) paste("lp", i, sep = "")))

  # the formual for the multinomial regression
  CM_form <- paste0('outcome ~ ',
                    paste(sapply(1:nbCR, function(i) paste0('lp', i)),
                          collapse = ' + '))

  # collect the slopes of the multinomial regression with the linear preds as
  # only variable(s)
  slopes <- vglm(CM_form, family = multinomial(refLevel = r),
                 data = df,
                 constraints = clist)
  coeffslopes <- coefficients(slopes)[(nbCR+1):length(coefficients(slopes))]

  # for the confidence intervals:
  se <- sqrt(diag(vcov(slopes)))
  CSs <- list()
  for(i in 1:nbCR){
    CSs[[i]] <- cbind(LL = coeffslopes[i] - qnorm(0.975) * se[nbCR + i],
                      CS = coeffslopes[i],
                      UL = coeffslopes[i] + qnorm(0.975) * se[nbCR + i])
  }
  names(CSs) <- names(table(outcome))[-1]
  int <- vglm(outcome ~ 1, offset = lambdas, family = multinomial(refLevel = r))
  CI <- coefficients(int)
  se.int <- sqrt(diag(vcov(int)))
  names(CI) <- names(table(outcome))[-1]
  CIs <- list()
  for(i in 1:nbCR){
    CIs[[i]] <- cbind(LL = CI[i] - qnorm(0.975) * se.int[i],
                      CS = CI[i],
                      UL = CI[i] + qnorm(0.975) * se.int[i])
  }
  names(CIs) <- names(table(outcome))[-1]

  loglik <- function(mu, y, eta,
                     extra = NULL, summation = TRUE) {
    ycounts <-  y
    smallno <- 10000 * .Machine$double.eps
    if (max(abs(ycounts - round(ycounts))) > smallno)
      warning("converting 'ycounts' to integer in @loglikelihood")
    ycounts <- round(ycounts)
    ll.elts <- dmultinomial(x = ycounts, size = NULL, prob = mu,
                            log = TRUE, dochecking = FALSE)
    if (summation) {
      sum(ll.elts)
    }
    else {
      ll.elts
    }
  }

  model_without <- vglm(CM_form, family = multinomial(refLevel = r),
                        data = df)
  # logLik(slopes)
  parameters <- c(rep(0, nbCR), 1, rep(0, nbCR - 1), 0, 1, 0, 0,
                  0, 0, 1, 0, 0, 0, 0, 1)
  eta_without <- matrix((model.matrix(model_without) %*% parameters)[, 1],
                        ncol = nbCR, nrow = nrow(df), byrow = TRUE)
  mu_without <- exp(eta_without) / (1 + rowSums(exp(eta_without)))
  mu_without <- cbind(1 - rowSums(mu_without), mu_without)
  deviance_without <- -2*loglik(mu = mu_without, y = depvar(model_without), eta = eta_without)

  poverall <- pchisq(deviance_without - deviance(slopes), df = 2*nbCR,
                     lower.tail = FALSE)

  pslopes <- pchisq(deviance(int) - deviance(slopes), df = nbCR,
                    lower.tail = FALSE)
  pint <- pchisq(deviance_without - deviance(int), df = nbCR,
                 lower.tail = FALSE)

  return(list(Calibration.slopes = CSs,
              Calibration.intercepts = CIs,
              p.overall = poverall,
              p.slopes = pslopes,
              p.int = pint))
}
