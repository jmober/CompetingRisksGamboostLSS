discrimination <- function(predictedProbs, time_points, event_of_interest,
                           data, name_outcome, name_timeVar,
                           conditional_to = NULL){
  #' Cause-specific time-dependent AUC and C-index
  #'
  #'
  #' This function first computes the cause-specific time-dependent AUC, and
  #' then does a weighted sum of it over time to get the cause-specific C-index.
  #' @param predictedProbs a matrix with the predicted discrete-time hazards in
  #' a long format. The column names are the names of the competing risks.
  #' (evaluated for the testing data set with a model developed in the training data)
  #' @param time_points points in time for which the AUC is calculated and over
  #' which the C-index is evaluated.
  #' @param event_of_interest name of the event of interest among the competing
  #' risks.
  #' @param data the testing data set of the same row length as the
  #' predictedProbs-Matrix
  #' @param name_outcome name of the composite outcome variable
  #' @param name_timeVar name of the time variable
  #' @param conditional_to should the conditional C-index be computed? If yes,
  #' conditional to being at how many day before?
  #' @return a list with the time-dependent auc (vector) and the C-index
  #' @import biostatUZH
  #' @export

  AUC_tp <- sapply(time_points, function(t){
    t_cases <-
      which(data[ , name_timeVar] == t &
              data[, name_outcome] == event_of_interest)
    t_controls <-
      which(data[ , name_timeVar] == t &
              data[, name_outcome] != event_of_interest)
    cases_probs <- predictedProbs[t_cases, event_of_interest]
    controls_probs <- predictedProbs[t_controls, event_of_interest]
    if (length(cases_probs >= 1)){
      ci_auc <- biostatUZH::confIntAUC(cases = cases_probs,
                                       controls = controls_probs)
      return(ci_auc$AUC[1])
    } else return(NA)
  })

  AUC_tp_forC <- AUC_tp
  AUC_tp_forC[which(is.na(AUC_tp))] <- .5

  # computation of the weights for the C-index: *****
  df <- data[ , c(name_outcome, name_timeVar)]
  model <- VGAM::vglm(formula = paste0(name_outcome, '~ns(',
                                       name_timeVar, ',df=4)'),
                      data = df, family = multinomial(refLevel = 1))
  new.df <- data.frame((unique(df[ , name_timeVar])))
  colnames(new.df) <- name_timeVar
  Pr <- predictvglm(model, newdata = new.df, type = 'response')[ ,-1]
  Pr_r <- Pr[, event_of_interest]
  Pr_r_t <-
    (Pr_r * c(1, cumprod(1 - rowSums(Pr))[-nrow(Pr)]))[
      new.df[ , name_timeVar]%in%time_points]
  Pr_largert <-
    cumprod(1 - rowSums(Pr))[new.df[ , name_timeVar]%in%time_points]
  if (!is.null(conditional_to)){
    Pr_r_t <- Pr_r * c(1, cumprod(1 - rowSums(Pr))[-nrow(Pr)])
    Pr_r_t <- Pr_r_t/c(rep(1,conditional_to),
                   Pr_r_t[-((length(Pr_r_t)-conditional_to + 1):length(Pr_r_t))])
    Pr_largert <- cumprod(1 - rowSums(Pr))
    Pr_largert <-
      Pr_largert / c(rep(1,conditional_to),
                     Pr_largert[-((length(Pr_largert)-conditional_to + 1):
                                    length(Pr_largert))])
  }
  # ******


  C <- sum(AUC_tp_forC * Pr_r_t * Pr_largert)/sum(Pr_r_t * Pr_largert)

  return(list(time_dependent_auc = AUC_tp, Cindex = C))
}


# inverse probability of censoring weighting as in Blanche et al (2015)
# this is cause-specific IPCW!
IPCW <- function(timePoint, name_under_risk = 'ventilated',
                 nameID = 'ID', nameOutcome = 'outcomePlus',
                 nameTimevar = 'day_vent', trainData, testData){
  #' Inverse probability of censoring weights (IPCW)
  #'
  #'
  #' This function computes the IPCW which will then be used to compute scores
  #' @param timePoint for which time point should the IPCW be computed?
  #' @param name_under_risk name of the outcome level 'at risk'
  #' @param nameID name to extract the correct observation identifier
  #' @param nameOutcome name of the composite outcome variable
  #' @param nameTimevar name of the time variable
  #' @param trainData the training dataset
  #' @param testData the testing dataset
  #' @return a vector with the IPCW weights
  #' @import discSurv
  #' @export
  data_sub <- trainData[, c(nameID, nameTimevar, nameOutcome)]
  # censoring indicators for each observation, 1 if censored, 0 if
  # event or still observed
  data_sub$yCens <- 0
  for (i in 1:(length(unique(data_sub[,nameID])))){
    who <- which(data_sub[,nameID] == unique(data_sub[, nameID])[i])
    if (length(who) > 1){
      data_sub[who, 'yCens'] <-
        c(rep(0, length(who) - 1),
          ifelse(data_sub[tail(who, 1), nameOutcome] != name_under_risk,
                 0, 1))
    } else {
      data_sub[who, 'yCens'] <- ifelse(data_sub[tail(who, 1),
                                                nameOutcome] != name_under_risk,
                                       0, 1)
    }
  }

  # lifetable method on the data to get the survival function of the censoring
  # distribution
  tempLifeTab <- lifeTable(dataSet = data_sub,
                           timeColumn = nameTimevar, censColumn = 'yCens')
  preG <- c(1, tempLifeTab[[1]][, "S"])

  # The event times
  event_times <-
    unname(sapply(unique(testData[, nameID]),
                  function(id) testData[tail(which(testData[ , nameID] == id),
                                             1), nameTimevar]))
  # the names of the final events
  final_events <-
    unname(sapply(unique(testData[, nameID]),
                  function(id) testData[tail(which(testData[ , nameID] == id),
                                             1), nameOutcome]))

  weights <- (event_times > timePoint)/preG[timePoint] +
    (event_times == timePoint)/preG[event_times] *
    (final_events != name_under_risk)

  return(data.frame(cbind(Weights = weights, ET = event_times)))
}


# area under the ROC curve as in Blanche et al (2015)
AUC_Li <- function(timepoint, probs, times, causeOFinterest, outcomes){

  #' Time-dependent area under the curve as in Li et al
  #'
  #'
  #' This function computes the AUC for a certain timepoint as in Li et al when
  #' all the event times are known, no censoring
  #' @param timePoint for which time point should the AUC be computed be computed?
  #' @param probs the estimated / fitted cause-specific risks (from: predictvglm)
  #' @param times vector with event times (long format: for a patient having an event at timepoint 5: c(1,2,3,4,5)
  #' @param causeOFinterest name of the cause of interest
  #' @param outcomes vector with the outcomes (long format:  for a patient having an event at timepoint 5: c('at risk','at risk','at risk','at risk','event'))
  #' @return time-dependent AUCs
  #' @export

  # the hazards at the specific timepoint
  pis <- probs[which(times == timepoint), causeOFinterest]
  # the events occuring at the specific timepoint
  out <- outcomes[which(times == timepoint)]
  # the numerator for the auc calculation
  NUM <- sum(sapply(1:length(pis), function(i){
    sum(sapply(1:length(pis), function(j){
      ((pis[i] > pis[j]) + .5*(pis[i] == pis[j])) * (out[i] == causeOFinterest) *
        (1 - (out[j] == causeOFinterest))
    }))
  }))
  # the denumerator for the auc calculation
  DENOM <- sum(sapply(1: length(pis), function(i){
    sum(sapply(1:length(pis), function(j){
      (out[i] == causeOFinterest) * (1 - (out[j] == causeOFinterest))
    }))
  }))
  return(NUM/DENOM)
}


Cindex <- function(timedep_AUC, timePoints, times, causeOFinterest, outcomes,
                   conditional_to = NULL){
  #' C-index.
  #'
  #'
  #' This function computes the C-index from a time-dependent AUC curve
  #' @param timedep_AUC vector with time dependent AUCs for which the c-index should
  #' be computed
  #' @param timePoints points in time for which the C-index should be computed for
  #' @param times vector with event times (long format)
  #' @param causeOFinterest name of the cause of interest
  #' @param outcomes vector with the outcomes (long format)
  #' @param conditional_to should the conditional C-index be computed? If yes,
  #' conditional to being at how many day before?
  #' @return the C-index
  #' @export
  df <- data.frame(OUT = outcomes, TIMES = times)
  model <- VGAM::vglm(formula = OUT ~ ns(TIMES,  df = 4),
                      data = df, family = multinomial(refLevel = 1))
  newdf <- data.frame(TIMES = unique(times))
  weights <- predictvglm(model, newdata = newdf, type = 'response')[ ,-1]
  lambda <- weights[, causeOFinterest]

  Pr_t <- (lambda * c(1, cumprod(1 - rowSums(weights))[-nrow(weights)]))[newdf$TIMES%in%timePoints]
  Pr_largert <- cumprod(1 - rowSums(weights))[newdf$TIMES%in%timePoints]

  if (!is.null(conditional_to)){
    Pr_t <- lambda * c(1, cumprod(1 - rowSums(weights))[-nrow(weights)])
    Pr_t <- Pr_t/c(rep(1,conditional_to),
                   Pr_t[-((length(Pr_t)-conditional_to + 1):length(Pr_t))])
    Pr_largert <- cumprod(1 - rowSums(weights))
    Pr_largert <-
      Pr_largert / c(rep(1,conditional_to),
                     Pr_largert[-((length(Pr_largert)-conditional_to + 1):
                                    length(Pr_largert))])
  }
  C <- sum(timedep_AUC * Pr_t * Pr_largert,
           na.rm = TRUE)/sum(Pr_t * Pr_largert, na.rm = TRUE)

  return(C)
}

