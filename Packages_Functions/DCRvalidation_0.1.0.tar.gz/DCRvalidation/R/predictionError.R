PE_Curve_CR <- function(train, test, varName_identifier = 'ID',
                        varName_time = 'day_vent',
                        varName_outcome = 'outcomePlus', hazards,
                        start = 5, uptoTIME = 126 + 1,
                        weights = FALSE){
  #' Prediction error curve for competing risks models
  #'
  #'
  #' This function computes the prediction error (PE) from the predicted hazard
  #' @param train the training dataset
  #' @param test the test or validation dataset.
  #' @param varName_identifier name to extract the correct observation identifier
  #' @param varName_time name of the time variable
  #' @param varName_outcome name of the composite outcome variable
  #' @param hazards the predicted hazards in a long format
  #' @param start first day of observation
  #' @param uptoTIME until which timepoint should the PE be computed
  #' @param weights should be accounted for IPCW weights?
  #' @return an object of class \code{PE_Curve_CR}
  #' @import VGAM Ecdat
  #' @export
  #' @examples
  #' # extract the data:
  #' library(Ecdat)
  #' library('VGAM')
  #' set.seed(1)
  #' samp <- sample(1:nrow(UnempDur), 2500)
  #' UnempDurLong_train <- dataLongCompRisks(dataSet = UnempDur[samp, ],
  #'  timeColumn="spell", eventColumns = c("censor1", "censor2",
  #'  "censor3", "censor4"))
  #' UnempDurLong_train$CompRisk <- ifelse(UnempDurLong_train$e1 == 1, 'full-time',
  #'                                       ifelse(UnempDurLong_train$e2 == 1,
  #'                                       'part-time', ifelse(
  #'                                       UnempDurLong_train$e3 == 1,
  #'                                       'employed_but_left', 'unemployed')))
  #' UnempDurLong_train$CompRisk <- as.factor(UnempDurLong_train$CompRisk)
  #' UnempDurLong_train$CompRisk <- relevel(UnempDurLong_train$CompRisk,
  #'                                        ref = 'unemployed')
  #' UnempDurLong_train$timeInt <- as.numeric(UnempDurLong_train$timeInt)
  #' UnempDurLong_test <- dataLongCompRisks(dataSet =  UnempDur[-samp, ],
  #'                                        timeColumn="spell",
  #'                                        eventColumns = c("censor1",
  #'                                                         "censor2",
  #'                                                         "censor3",
  #'                                                         "censor4"))
  #' UnempDurLong_test$CompRisk <- ifelse(UnempDurLong_test$e1 == 1, 'full-time',
  #'                                      ifelse(UnempDurLong_test$e2 == 1,
  #'                                      'part-time', ifelse(
  #'                                      UnempDurLong_test$e3 == 1,
  #'                                      'employed_but_left', 'unemployed')))
  #' UnempDurLong_test$CompRisk <- as.factor(UnempDurLong_test$CompRisk)
  #' UnempDurLong_test$CompRisk <- relevel(UnempDurLong_test$CompRisk,
  #'                                       ref = 'unemployed')
  #' UnempDurLong_test$timeInt <- as.numeric(UnempDurLong_test$timeInt)
  #' form <- CompRisk ~ timeInt + age + logwage
  #' model <- vglm(formula = form, data = UnempDurLong_train,
  #'               family = multinomial(refLevel = 1))
  #' pred <- predictvglm(model, newdata = UnempDurLong_test, type = "response")
  #' hazards <- pred[ , -1]
  #'
  #' pe <-  PE_Curve_CR(train = UnempDurLong_train, test = UnempDurLong_test,
  #'                    varName_identifier = 'obj', varName_time = 'timeInt',
  #'                    varName_outcome = 'CompRisk', hazards = hazards,
  #'                    start = 1, uptoTIME = 28)
  #'
  #' plot_PE(pe, cause = 'employed_but_left')
  #' plot_PE(pe, cause = 'full-time', add = TRUE, color = 2)
  #' plot_PE(pe, cause = 'part-time', add = TRUE, color = 3)
  #' @author Rachel Heyard
  #'
  if (weights){
    w <- lapply(start:uptoTIME, function(t) {
      IPCW(timePoint = t,
           name_under_risk = 'unemployed',
           nameID = 'obj', nameOutcome = 'outcome',
           nameTimevar = 'timeInt',
           trainData = UnempDur_longTRAIN,
           testData = UnempDur_longTEST)})
  }

  rownames(hazards) <- test[ , varName_identifier] # to find them later

  # the outcomes
  causes <- colnames(hazards)
  numberOFcauses <- length(causes)

  # blow up the hazard matrix, to keep patient at risk after death
  # last observation carried forward
  Haz <- lapply(as.character(unique(rownames(hazards))), function(name) {
    ids <- which(rownames(hazards) == name)
    if (length(ids) + (start-1) >= uptoTIME){
      HAZARDS <- hazards[head(ids, uptoTIME - (start - 1)), ]
    } else {
      MAT <- matrix(hazards[tail(ids, 1),],
                    nrow = uptoTIME - length(ids) - (start-1),
                    ncol = numberOFcauses, byrow = TRUE)
      HAZARDS <- rbind(hazards[ids, ], MAT)
    }
    rownames(HAZARDS) <- rep(name, nrow(HAZARDS))
    return(HAZARDS)
  })
  HAZARDS <- do.call(rbind, Haz)

  # sum of the cause-specific hazards
  sum_cs_HAZ <- rowSums(HAZARDS)

  # test data event type and times:
  test_time <- aggregate(formula = as.formula(paste(varName_time, ' ~ ',
                                                    varName_identifier,
                                                    sep = '')),
                         data = test, FUN = function(x) tail(x, 1))
  test_event <- aggregate(formula = as.formula(paste(varName_outcome, ' ~ ',
                                                     varName_identifier,
                                                     sep = '')),
                          data = test, FUN = function(x) tail(x, 1))


  # the probability that nothing happens until time t for each patient:
  predicted_P00 <- lapply(unique(test[ , varName_identifier]), function(id) {
    MAT <- 1 - rowSums(HAZARDS[which(rownames(HAZARDS)==id),])
    return(cumprod(MAT))
  })
  names(predicted_P00) <- unique(test[ , varName_identifier])

  # the probability of having an event 'j' at time t for each patient and
  # each j = 1, ..., numberOFcauses
  predicted_P0j <-
    lapply(unique(test[ , varName_identifier]), function(id) {
      inList <- which(names(predicted_P00) == as.character(id))
      P <- predicted_P00[[inList]]
      return(unname(c(1, P[-length(P)]))*HAZARDS[which(rownames(HAZARDS) == id), ])
    })

  # The cause-specific cumulative incidence function for each patient (at each time)
  predicted_cifs <- lapply(predicted_P0j, FUN = function(x) {
    if (!is.null(nrow(x))) {
      return(apply(x, MARGIN = 2, FUN = cumsum))
    } else return(x)
  })

  # Observed event times by causes:
  observed <- lapply(causes, function(c){
    lapply(1:nrow(test_time), function(i) {
      if (test_time[ , varName_time][i] == start){
        rep(ifelse(test_event[, varName_outcome][i] == c, 1, 0),
            uptoTIME - (start - 1))
      } else {
        if (test_time[ , varName_time][i] > uptoTIME){
          rep(0, uptoTIME - (start - 1))
        } else {
          c(rep(0, test_time[, varName_time][i] - start),
            rep(ifelse(test_event[, varName_outcome][i] == c, 1, 0),
                uptoTIME - test_time[ , varName_time][i] + 1))
        }
      }
    })
  })
  names(observed) <- causes

  # The cifs by cause and patient
  cifs <- lapply(causes, function(c){
    lapply(predicted_cifs, function(x) {
      if (!is.null(nrow(x))){
        return(unname(x[, c]))
      } else {return(unname(x[1]))}
    })
  })
  names(cifs) <- causes

  # the squared differences by cause and patient
  Squared_diffs <- lapply(causes, function(c) {
    lapply(1:length(cifs[[c]]), function(i){
      (observed[[c]][[i]] - cifs[[c]][[i]])**2
    })
  })
  names(Squared_diffs) <- causes
  # rearrange the squared differences by time, so a list of length of causes,
  # then a list of length of patients and with vectors of length uptoTIME
  Squared_diffs_bytime <- lapply(causes, function(c){
    lapply(start:uptoTIME, function(t){
      diffsATtime_t <- rep(NA, length(Squared_diffs[[c]]))
      for (i in 1:length(Squared_diffs[[c]])){
        if (!weights){
          diffsATtime_t[i] <- Squared_diffs[[c]][[i]][t - (start - 1)]
        } else {
          diffsATtime_t[i] <-
            Squared_diffs[[c]][[i]][t - (start - 1)] *
            w[[t - (start - 1)]]$Weights[i]
        }

      }
      return(diffsATtime_t)
    })
  })
  names(Squared_diffs_bytime) <- causes

  # The prediction error curves:
  estimated_PEs <- lapply(causes, function(c){
    if (is.null(weights)) {
      sapply(Squared_diffs_bytime[[c]], function(x) mean(x, na.rm = TRUE))
    } else {
      sapply(Squared_diffs_bytime[[c]], function(x) mean(x, na.rm = TRUE))
    }
  })
  names(estimated_PEs) <- causes

  return(list(CIF = cifs, PE_cs = estimated_PEs,
              input = list(formula = formula, train = train, test = test,
                           varName_identifier = varName_identifier,
                           varName_time = varName_time,
                           varName_outcome = varName_outcome,
                           start = start, uptoTIME = uptoTIME)))
}


conditionalPE_Curve_CR<- function(train, test, varName_identifier = 'ID',
                                  varName_time = 'day_vent',
                                  varName_outcome = 'outcomePlus', hazards,
                                  start = 5, uptoTIME = 126 + 1,
                                  conditional_to = 2){
  #' Conditional prediction error curve for competing risks models
  #'
  #'
  #' This function computes the conditional prediction error (PE) curve
  #' from the predicted conditional predictions
  #' @param train the training dataset
  #' @param test the test or validation dataset.
  #' @param varName_identifier name to extract the correct observation identifier
  #' @param varName_time name of the time variable
  #' @param varName_outcome name of the composite outcome variable
  #' @param hazards the predicted hazards in a long format
  #' @param start first day of observation
  #' @param uptoTIME until which timepoint should the PE be computed
  #' @param conditional_to should the conditional C-index be computed? If yes,
  #' conditional to being at how many day before?
  #' @return an object of class \code{conditionalPE_Curve_CR}
  #' @export
  #' @examples
  #' @author Rachel Heyard

  rownames(hazards) <- test[ , varName_identifier] # to find them later

  # the outcomes
  causes <- colnames(hazards)
  numberOFcauses <- length(causes)

  # test data event type and times:
  test_time <- aggregate(formula = as.formula(paste(varName_time, ' ~ ',
                                                    varName_identifier,
                                                    sep = '')),
                         data = test, FUN = function(x) tail(x, 1))

  test_event <- aggregate(formula = as.formula(paste(varName_outcome, ' ~ ',
                                                     varName_identifier,
                                                     sep = '')),
                          data = test, FUN = function(x) tail(x, 1))

  # spilt hazards into time-dependent (still at) risk hazard matrixes:
  HAZ <- lapply(start:uptoTIME, function(t){
    # repeat original test 'conditional_to' + 1 times:
    if (t %in% start:(start + conditional_to)){
      return(hazards)
    } else {
      which_rows <- which(test[, varName_time] >= t - conditional_to)
      return(hazards[which_rows, ])
    }
  })
  names(HAZ) <- sapply(start:uptoTIME, function(t) paste0('T = ', t))

  # blow up the hazard matrix, to keep patient at risk after death
  # last observation carried forward
  # we 'observe' the patients from t - conditional_to' to 'uptoTIME'
  HAZARDS <- lapply(1:length(HAZ), function(h.ind){
    H <- HAZ[[h.ind]]
    timepoint <- (start:uptoTIME)[h.ind]
    if (timepoint < start + conditional_to) timepoint <- start + conditional_to
    # the first 'conditional_to + 1' sets stay the same
    H.big <- lapply(as.character(unique(rownames(H))), function(name) {
      ids <- which(rownames(H) == name)
      if (test_time$day_vent[which(test_time$ID == name)] >= uptoTIME){
        hazz <- # if the subject is observed until the final timepoint of interest
          # or longer, extract the info from up to that final timepoint of interest
          H[head(ids, uptoTIME - (timepoint - conditional_to) + 1), ]
      } else {
        MAT <- # if the subject isn't observed until the final timepoint of interest
          # blow up the hazard matrix, with the last obs. carried forward.
          matrix(H[tail(ids, 1),],
                 nrow = uptoTIME - (timepoint - conditional_to) - length(ids) + 1,
                 ncol = numberOFcauses, byrow = TRUE)
        hazz <- rbind(H[ids, ], MAT)
      }
      rownames(hazz) <- rep(name, nrow(hazz))
      return(hazz)
    })
    return(do.call(rbind, H.big))
  })
  names(HAZARDS) <- names(HAZ)

  # Observed event times by time and caues (they only observed if still at risk
  # at t - 'conditional_to':
  observed <- lapply(start:uptoTIME, function(t){
    obs <- lapply(causes, function(c){
      o <- lapply(1:nrow(test_time), function(i) {
        if(test_time[, varName_time][i] >= t - conditional_to){
          if (test_time[ , varName_time][i] == t){
            ifelse(test_event[, varName_outcome][i] == c, 1, 0)
          } else {
            0
          }
        }
      })
      return(o[!sapply(o,is.null)])
    })
    names(obs) <- causes
    return(obs)
  })
  names(observed) <- names(HAZ)


  # the probability that nothing happens until time t for each patient:
  predicted_P00 <- lapply(HAZARDS, function(h) {
    pr <- lapply(unique(rownames(h)), function(id) {
      MAT <- 1 - rowSums(h[which(rownames(h)==id),])
      return(cumprod(MAT))
    })
    names(pr) <- unique(rownames(h))
    return(pr)
  })
  names(predicted_P00) <- names(HAZ)

  df <- test[ , c(varName_time, varName_outcome)]
  model <- VGAM::vglm(formula = paste0(varName_outcome, '~ns(',
                                       varName_time, ',df=4)'),
                      data = df, family = multinomial(refLevel = 1))
  new.df <- data.frame((unique(df[ , varName_time])))
  colnames(new.df) <- varName_time
  Pr <- predictvglm(model, newdata = new.df, type = 'response')[ ,-1]
  Pr_largert <-
    cumprod(1 - rowSums(Pr))

  # the conditional probability of having an event 'j' at time t for each patient and
  # each j = 1, ..., numberOFcauses
  predicted_P0j <- lapply(1:length(HAZARDS), function(h){
    H <- HAZARDS[[h]]
    list <-
      lapply(unique(rownames(H)), function(id) {
        inList <- which(names(predicted_P00[[h]]) == as.character(id))
        if(length(inList) > 0){
          P <- predicted_P00[[h]][[inList]]
          return(unname(c(1, P[-length(P)]))*H[which(rownames(H) == id), ]/Pr_largert[seq_along(P)])
        }
      })
    return(list[!sapply(list,is.null)])
  })
  names(predicted_P0j) <- names(HAZ)

  # The cause-specific conditional cumulative incidence function for each patient (at each time)
  predicted_cifs <- lapply(1:length(predicted_P0j), function(t)
    lapply(predicted_P0j[[t]], FUN = function(x) {
      if (!is.null(nrow(x))) {
        return(apply(x, MARGIN = 2, FUN = sum))
      } else return(x)
    }))
  names(predicted_cifs) <- names(HAZ)

  # The cifs by cause and patient for each T:
  cifs <- lapply(1:length(predicted_cifs), function(t){
    res <- lapply(causes, function(c)
      lapply(predicted_cifs[[t]], function(x) {
        #if (!is.null(nrow(x))){
        return(unname(x[c]))
        # } else {return(unname(x[1]))}
      }))
    names(res) <- causes
    return(res)
  })
  names(cifs) <- names(HAZ)

  # the squared differences by cause and patient
  Squared_diffs <- lapply(1:length(observed), function(t){
    Sd <- lapply(causes, function(c)
      lapply(1:length(cifs[[t]][[c]]), function(i)
        (head(observed[[t]][[c]][[i]], 1) - cifs[[t]][[c]][[i]])**2
      ))
    names(Sd) <- causes
    return(Sd)
  })
  names(Squared_diffs) <- names(HAZ)

  # rearrange the squared differences by time, so a list of length of causes,
  # then a list of length of patients and with vectors of length uptoTIME
  Squared_diffs_bytime <- lapply(1:length(Squared_diffs), function(tp){
    sdt <- lapply(causes, function(c){
      lapply(1:length(Squared_diffs[[tp]][[c]][[1]]), function(t){
        diffsATtime_t <- rep(NA, length(Squared_diffs[[tp]][[c]]))
        for (i in 1:length(Squared_diffs[[tp]][[c]])){
          diffsATtime_t[i] <- Squared_diffs[[tp]][[c]][[i]][t]
        }
        return(diffsATtime_t)
      })
    })
    names(sdt) <- causes
    return(sdt)
  })
  names(Squared_diffs_bytime) <- names(HAZ)

  # The prediction error curves:
  estimated_PEs <- lapply(1:length(Squared_diffs_bytime), function(tp){
    estPEs <- lapply(causes, function(c){
      sapply(Squared_diffs_bytime[[tp]][[c]],
             function(x) mean(x, na.rm = TRUE))
    })
    names(estPEs) <- causes
    return(estPEs)
  })
  names(estimated_PEs) <- names(HAZ)

  condPE <- lapply(causes, function(c)
    sapply(estimated_PEs, function(pe)
      pe[[c]]))
  names(condPE) <- causes
  return(list(condPE = condPE,
              input = list(formula = formula, train = train, test = test,
                           varName_identifier = varName_identifier,
                           varName_time = varName_time,
                           varName_outcome = varName_outcome,
                           start = start, uptoTIME = uptoTIME,
                           conditional_to = conditional_to)))
}

integratedPE <- function(PEobject){
  #' Integrated prediction error curve for competing risks models
  #'
  #' This function computes the cause-specific integrated prediction error (IPE) from PE curve object
  #' @param PEobject an object computed by the \code{PE_Curve_CR} function
  #' @return a vetcor with the cause-specific IPEs
  #' @export
  form <- paste0(PEobject$input$varName_outcome, '~ ns(',
                 PEobject$input$varName_time, ',df=4)')
  model <- VGAM::vglm(formula = form,
                      data = PEobject$input$test,
                      family = multinomial(refLevel = 1))
  causes <- names(PEobject$PE_cs)
  timePoints <- PEobject$input$start:PEobject$input$uptoTIME
  newdf <- data.frame(TIMES = timePoints)
  colnames(newdf) <- PEobject$input$varName_time
  weights <- predictvglm(model, newdata = newdf, type = 'response')[,-1]

  ipes <- sapply(causes, function(c){
    lambda <- weights[, c]
    Pr_t <- lambda * c(1, cumprod(1 - rowSums(weights))[-length(timePoints)])

    return(sum(PEobject$PE_cs[[c]] * Pr_t))
  })

  names(ipes) <- causes
  return(ipes)
}


# prediction error curve
plot_PE <- function(PE_object, cause, color = 1, ylim = c(0,.3),
                    main = NULL, xlab = NULL, ylab = NULL,
                    lwd = 1.5, add = FALSE, bars = FALSE, lty = 1){
  #' Plot the prediction error curve
  #'
  #' This function plots the prediction error curves for each competing event
  #' @param PE_object object built by the
  #' @param cause for which cause the prediction error curve should be plotted?
  #' @param color color
  #' @param ylim limit of the y axes by default c(0, .3)
  #' @param main title
  #' @param xlab title of the x axes
  #' @param ylab title of the yaxes
  #' @param lwd line width
  #' @param add should the curve be added to an existing plot? (default: FALSE)
  #' @param bars with barplot for the remaining events of cause \code{cause} in
  #'  the test data, yes or no?
  #' @return a plot
  #' @export
  #'
  # if (bars) nbEVENTS <- sapply(PE_object$input$start:PE_object$input$uptoTIME,
  #                              function(time){
  #                                test <- PE_object$input$test
  #                                tab <- table(
  #                                  test[which(test[, PE_object$input$varName_time] >= time),
  #                                       PE_object$input$varName_outcome])
  #                                unname(tab[cause])
  #                              })

  # if (bars) par(mar=c(5, 4, 4, 5) + 0.1)
  if (!add){
    plot(PE_object$input$start:PE_object$input$uptoTIME,
         PE_object$PE_cs[[cause]], ylim = ylim, main = main,
         xlab = xlab, ylab = ylab, lwd = lwd, col = color,
         type = 's', lty = lty)
  } else {
    lines(PE_object$input$start:PE_object$input$uptoTIME,
          PE_object$PE_cs[[cause]], col = color, lwd = lwd,
          type = 's', lty = lty)
  }

  # if (!add & bars){
  #   par(new=TRUE)
  #   plot(PE_object$input$start:PE_object$input$uptoTIME,
  #        nbEVENTS/sum(nbEVENTS)*100,
  #        type = 'h', xaxt = 'n', yaxt='n',
  #        xlab = '', ylab = '', axes = FALSE)
  #   mtext(paste0('Percentage of remaining ', cause, ' events of all ', cause,
  #                ' events'), side=4, line=4)
  #   axis(4, ylim = c(0, max(nbEVENTS/sum(nbEVENTS)*100)), las=1)
  #   par(new=FALSE)
  # }
}

plot_RER <- function(PE_of_interest, PE_null, cause, add = FALSE,
                     main = NULL, xlab = NULL, ylab = NULL,
                     lwd = 1.5, color, ylim = c(-.5,1), lty = 1){
  #' Plot of the relative error reduction
  #'
  #' This function relative error reduction
  #' @param PE_of_interest object built by the PE_Curve_CR function
  #' @param PE_null PE_Curve_CR object of the null model
  #' @param cause for which cause the prediction error curve should be plotted?
  #' @param color color
  #' @param ylim limit of the y axes by default c(0, .3)
  #' @param main title
  #' @param xlab title of the x axes
  #' @param ylab title of the y axes
  #' @param lwd line width
  #' @param add should the curve be added to an existing plot? (default: FALSE)
  #' @return a plot
  #' @export
  #'

  if (is.null(ylab)) ylab <- 'Prediction error reduction'

  RER <-
    (PE_null$PE_cs[[cause]] - PE_of_interest$PE_cs[[cause]])/ PE_null$PE_cs[[cause]]

  if (!add){
    plot(PE_of_interest$input$start:PE_of_interest$input$uptoTIME,
         RER, type = 's', ylab = ylab, main = main, lty = lty,
         xlab = xlab, lwd = lwd, col = color, ylim = ylim)
  } else {
    lines(PE_of_interest$input$start:PE_of_interest$input$uptoTIME,
          RER, type = 's', lwd = lwd, col = color, lty = lty)
  }
}
